"""Data model used by the Gate Framework

The root object is the `UTScopeConfig` object. A single instance of this class
will completely describe the method for making measurements on "raw" A-scans.
This includes the parameters of the "raw" A-scan signals, how they should be
processed, the gates used to make the measurements, and even the configuration
of the display for the resulting measurements.

"""
import typing as t
from enum import Enum

import numpy as np
from pydantic import BaseModel

GateID = int


class TimeSelectionMode(str, Enum):
    """The ways in which a Time measurement can be made by a gate

    `flank` describes the first index within the bounds of the gate in which
    the signal is larger than the gates threshold.

    `peak` indicates the maximum value of the signal within the bounds of the
    gate.

    """

    # TODO: Consider other time selection reference points:
    # first_peak - the first peak, not necessarily the maximum peak
    # first_zero - the first zero crossing after the crossing edge
    # TODO: Consider other definitions of "peak": first peak, maximum peak,
    # last peak

    flank = "flank"
    peak = "peak"


class GateMeasurement(str, Enum):
    """The set of measurements produces by a single gate"""

    flank = TimeSelectionMode.flank.name
    peak = TimeSelectionMode.peak.name
    amplitude = "amplitude"


class UnitChoice(str, Enum):
    """Systems of units to choose from

    This class is helpful in enforcing some conventions around NDE measurements
    and the units that we use to describe them.

    """

    # UnitChoice | Distance  |  Thickness  | velocity
    # -----------|-----------|-------------|----------
    #     US     |   Feet    |   Inches    |   in/us
    #     SI     |  Meters   | Millimeters |    m/s

    US = "US"
    SI = "SI"

    # TODO: Look into pint.unit_systems which are a similar concept
    @property
    def distance_units(self):
        """For things like "distance traveled by the robot"

        Distance from the zero line, etc.
        """
        if self is self.US:
            units = "feet"
        else:
            units = "meters"
        return units

    @property
    def thickness_units(self):
        if self is self.US:
            units = "inches"
        else:
            units = "mm"
        return units

    @property
    def velocity_units(self):
        if self is self.US:
            units = "in./us"
        else:
            units = "m/s"
        return units

    def format_distance(self, distance: float):
        """Convenience method to format a given distance for display

        The distance is assumed to already be in the correct units

        """
        if self is self.US:
            # Convert decimal ft into ft/inch decimal inch
            inches = round(distance * 12, 2)
            ft = int(distance)
            inch = round((distance - ft) * 12, 2)
            formatted = f"{ft}'{inch}\" ({inches} inches)"
        else:
            formatted = f"{distance:6.3f} m"
        return formatted

    @property
    def thickness_fmt(self):
        if self is self.US:
            fmt = "{:.3f}"
        else:
            fmt = "{:.2f}"
        return fmt

    @property
    def thickness_q_fmt(self):
        # Thickness format compatible with a pint quantity
        if self is self.US:
            fmt = "{:~.3f}"
        else:
            fmt = "{:~.2f}"
        return fmt

    @property
    def velocity_fmt(self):
        if self is self.US:
            fmt = "{:~6.4}"
        else:
            fmt = "{:~}"
        return fmt

    @property
    def increments_and_limits(self) -> t.Tuple[float, t.Tuple[float, float]]:
        """A reasonable step size and A reasonable limits for thickness

        These define how a user modifiable display value should change, for
        example a spinbox changed by the mouse wheel.

        """
        if self is self.US:
            step, limits = 0.05, (0, 4)
        else:
            step, limits = 1, (0, 101)
        return step, limits


class SampleSize(str, Enum):
    int16 = "int16"
    # TODO: It's unclear what the numpy format of 12 bit integers would be but
    # apparently it's common for the DAQ units to support it. Perhaps custom
    # unpacking is required?
    # int12: str = "int12"
    int8 = "int8"
    uint8 = "uint8"

    @property
    def dtype(self):
        """Returns the equivalent numpy dtype for the sample size"""
        return getattr(np, self.name)


class Digitizer(BaseModel):
    """Digitizer Configuration

    Parameters of the "raw" digital signals

    These describe the format of "raw" A-scans. If the DAQ unit applies
    down-sampling (sometimes called "compression"), then this value should
    match the resultant sampling rate.

    The defaults set here are the settings used by RC for the last few years.
    100MHz is highest sample_rate supported by the DAQs and 16 bit integers are
    the highest sample resolution.

    The only other configuration which is known to have been used in production
    in the past is a sample_rate of 100MHz and a sample_size of unsigned 8 bits
    which implies that rectification has already been applied to the signals.
    Also Note: We have also seen examples from Olympus where the A-scans are
    rectified but the actual data type is still signed 16 bits.

    """

    sample_rate: int = 100_000_000  # Hz
    sample_size: SampleSize = SampleSize.int16


class RectifierMode(str, Enum):
    """Options for applying rectification

    ``full wave``: All negative amplitude values are made positive, essentially
    the absolute value of all samples in the waveform.

    ``half wave positive``: All negative amplitude values are converted to zero
    amplitude with positive values being preserved

    ``half wave negative``: All positive amplitude values are converted to zero
    amplitude with negative values being preserved

    """

    full_wave = "full wave"
    half_wave_positive = "half wave positive"
    half_wave_negative = "half wave negative"


class ProcessorSettings(BaseModel):
    """Settings describing the processor pipeline

    The processor pipeline is the set of signal processing steps necessary to
    transform the raw A-scans before they are measured by gates.

    The defaults used here represent the most common configuration for RUG
    which uses 10MHz transducers.

    """

    # sample_rate here is the same as the value in Digitizer.sample_rate but
    # will differ when downsampling (aka compression) is implemented in the
    # processor pipeline.
    sample_rate: int = 100_000_000  # Hz
    front_padding: int = 100  # samples
    ascan_length: int = 1100  # Includes front_padding
    saturation_percent: int = 100
    filter_low_cutoff: float = 5e6  # Hz
    filter_high_cutoff: float = 15e6  # Hz
    rectification: RectifierMode = RectifierMode.full_wave
    smoother_max_length: int = 5
    smoother_avg_length: int = 10
    enable_filtering: bool = True
    enable_rectification: bool = True
    enable_smoothing: bool = False


class Gate(BaseModel):
    """A description of a Gate

    Gates which refer to another gate (reference_id is not None) form a
    sequence of gates. In the gate framework, the reference gate's flank
    measurement is used as the zero point for this gates start_index and
    end_index. See the gate implementation.

    """

    id: GateID = 0
    name: str
    threshold: t.Union[float, int]
    start_index: int
    end_index: int
    reference_id: t.Union[None, GateID] = None

    @property
    def shape(self):
        return self.threshold, self.start_index, self.end_index


class TCGPoint(BaseModel):
    """A point in the TCG curve.

    The factor is specified as a multiplier which can be converted to db using:
    20*log10(factor)

    """

    sample: int
    factor: float


TCGTemplate = t.List[TCGPoint]


class TCGCurve(BaseModel):
    """A description of the Time Varied Gain which should be applied

    Due to a limitation of the implementation, at the moment TCG must be
    applied with respect to one of the gates. So the reference `gate_id` value
    must not be None.

    """

    # TODO: Expand the _gate_impl to handle TCG being applied with respect to
    # sample 0 of the unaligned A-scans. This will require handling potentially
    # negative start samples in the case of applying TCG to aligned A-scans.
    gate_id: GateID = 0
    template: TCGTemplate = []


class MeasurementSettings(BaseModel):
    """Settings describing how A-scans will be measured using gates

    Due to a limitation of the current implementation `gates` is assumed to be
    the sequence of gates. Meaning that the individual gates must be in order
    and must form a sequence in that order.

    """

    # TODO: allow the system to support more than 1 gate sequence, or a tree of
    # gates
    gates: t.List[Gate]  # Assumed to be a sequence
    alignment_gate: GateID
    detection_mode: TimeSelectionMode = TimeSelectionMode.flank
    tcg_enabled: bool = False
    tcg_curve: TCGCurve = TCGCurve()

    @property
    def by_names(self):
        return dict([(gate.name, gate) for gate in self.gates])

    @property
    def by_ids(self):
        return dict([(gate.id, gate) for gate in self.gates])

    @property
    def gate_sequence(self):
        return self.gates[:]


GateSource = t.Tuple[GateID, GateMeasurement]
AlgorithmSource = str
CscanSource = t.Union[GateSource, AlgorithmSource]


class CscanSettings(BaseModel):
    """Settings describing how a measurement is intended to be visualized

    Although these may be application specific parameters, it simplified many
    things to include them here in the gate framework, and it also aligns with
    the idea a particular configuration of gates requires the user to specify
    which measurements they intend to use for this inspection and also what the
    meaning of each measurement is. These settings provide a way to do that by
    allowing the user to customize the title or color map or add deliberate
    filtering to a measurement accordingly.

    Notes:

    The color_min, color_max as well as the filter_min, filter_max are in the
    same units as the source measurement. So typically Time, or Amplitude in
    the gate framework.

    """

    # TODO: Consider how Boiler specific settings might be represented here.
    # Because we have binning settings, perhaps we also have to have ordering
    # parameters.
    source: CscanSource
    title: str
    quantity: str  # a label for the quantity in the heat-map
    color_map_name: str
    color_min: float
    color_max: float
    filter_min: t.Union[float, None]
    filter_max: t.Union[float, None]
    bin_size_1d: float
    bin_function: str

    @property
    def filter_bounds(self):
        if self.filter_min is None or self.filter_max is None:
            bounds = None
        else:
            bounds = (self.filter_min, self.filter_max)
        return bounds

    @property
    def color_levels(self):
        return (self.color_min, self.color_max)


class UTScopeConfig(BaseModel):
    """Root model

    An instance of this class provides all the information necessary to process
    and measure a collection of A-scans. The collection of A-scans which
    matches the "unit of work" for acquisition is a single Run, hence the name
    of this class. However it may often be the case that a single instance of
    this class describes the complete inspection.

    See also `gecko.gates.common.typical_rug_assumptions` for a helpful factory
    function for this class.

    """

    units: UnitChoice
    digitizer: Digitizer
    processor_settings: ProcessorSettings
    measurement_settings: MeasurementSettings
    material_velocity: t.Dict[str, float]  # gate_id or algorithm source to m/s
    cscan_settings: t.List[CscanSettings]
