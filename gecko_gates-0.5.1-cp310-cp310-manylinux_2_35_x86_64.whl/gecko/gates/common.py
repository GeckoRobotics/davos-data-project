"""Common methods useful to applications which provide support for gates

See ``typical_rug_assumptions`` for a factory function which helps to
initialize the complete data model for processing and measurement of A-scans in
RUG.

"""
import typing as t
from dataclasses import dataclass

import numpy as np
import pint
from numpy.typing import NDArray

from gecko.gates import models

FLANK = models.GateMeasurement.flank
PEAK = models.GateMeasurement.peak
AMPLITUDE = models.GateMeasurement.amplitude

# The composite dtype used to store the array of measurements made by a
# particular gate.
DENSITY_CSCAN_NAME = "Data Density"
CSCAN_DTYPE = np.dtype(
    {
        "names": [FLANK.name, PEAK.name, AMPLITUDE.name],
        "formats": [np.int16, np.int16, np.float32],
    }
)
Measurements = t.Dict[models.GateID, NDArray[t.Any]]
CONVENTIONAL_CMAPS = {
    "delay": "CET_L20",
    "thickness": "CET_R2_r",
    "amplitude": "CET_L1_r",
    "have_data": "gray",
    DENSITY_CSCAN_NAME: "CET_CBTL3_r",
}

ureg = pint.get_application_registry()
Q_ = ureg.Quantity


TYPICAL_STEEL_VELOCITY = 5890.0 * Q_("m/s")
TYPICAL_WATER_VELOCITY = 1480.0 * Q_("m/s")

TRANSDUCER_BANDS = {  # Units of MHz
    3.5e6: (2.00e6, 5.50e6),
    5.0e6: (2.00e6, 8.00e6),
    10.0e6: (5.00e6, 15.00e6),
}


def _samp_to_thick(samples, fs, V):
    """Convert round trip time to material thickness"""
    return (V * samples) / (2 * fs)


def _thick_to_samp(thickness, fs, V):
    """Convert material thickness to round trip time"""
    return (2 * fs * thickness) / (V)


def typical_rug_assumptions(
    three_gates: bool = True,
    transducer_freq: pint.Quantity = 10.0 * Q_("MHz"),
    material_velocity: pint.Quantity = TYPICAL_STEEL_VELOCITY,
    expected_nominal: pint.Quantity = 0.5 * Q_("in"),  # inches
):
    """Convenience function to instantiate a typical UTScopeConfig root class

    Use the arguments to provide a bit of additional information that will
    influence the settings used.

    The transducer freq is very important to get correct, while the other
    options just represent a convenience to the user.

    """
    units = models.UnitChoice.US
    digitizer = models.Digitizer()
    sample_rate = digitizer.sample_rate * Q_("Hz")
    nominal_samples = int(
        _thick_to_samp(expected_nominal, sample_rate, material_velocity)
        .to_reduced_units()
        .m
    )

    processor = models.ProcessorSettings()
    filter_band = TRANSDUCER_BANDS.get(transducer_freq.m, (5e6, 15e6))
    processor.filter_low_cutoff = filter_band[0]
    processor.filter_high_cutoff = filter_band[1]
    processor.ascan_length = processor.front_padding + int(2.5 * nominal_samples)

    measurement = sensible_default_gates(nominal_samples, three_gates)

    # The first gate measures the water column, subsequent gates measure
    # material
    velocities = {
        str(measurement.gates[0].id): TYPICAL_WATER_VELOCITY.to("m/s").m,
    }
    for gate in measurement.gates[1:]:
        velocities[str(gate.id)] = material_velocity.to("m/s").m

    cscans = sensible_default_cscans(
        units, processor, measurement, velocities, expected_nominal.m
    )
    return models.UTScopeConfig(
        units=units,
        digitizer=digitizer,
        processor_settings=processor,
        measurement_settings=measurement,
        material_velocity=velocities,
        cscan_settings=cscans,
    )


def sensible_default_gates(
    nominal_samples=430, three_gates=True
) -> models.MeasurementSettings:
    """Convenience function to return sensible default MeasurementSettings

    The arguments provides additional information that might be known about the
    inspection which will influence the defaults.

    """
    velocity_settings: t.Dict[models.GateID, float] = {}
    start_index = 125
    end_index = (1.25 * nominal_samples) if nominal_samples > start_index else 150

    sync_gate = models.Gate(
        name="Gate 0",
        threshold=90,
        start_index=100,
        end_index=1000,
    )
    velocity_settings[sync_gate.id] = TYPICAL_WATER_VELOCITY.m
    gate_a = _continue_sequence(
        sync_gate,
        name="Gate A",
        threshold=80,
        start_index=start_index,
        end_index=end_index,
    )
    gates = [sync_gate, gate_a]
    if three_gates:
        gate_b = _continue_sequence(
            gate_a,
            name="Gate B",
            threshold=0.90 * gate_a.threshold,
            start_index=gate_a.start_index,
            end_index=gate_a.end_index,
        )
        gates.append(gate_b)

    return models.MeasurementSettings(
        gates=gates, alignment_gate=sync_gate.id, tcg_enabled=False, tcg_curve=[]
    )


def sensible_default_cscans(
    units: models.UnitChoice,
    processor_settings: models.ProcessorSettings,
    measurement_settings: models.MeasurementSettings,
    material_velocity: t.Dict[t.Any, float],
    expected_nominal: float,
):
    """C-scans which are typically useful in RUG

    The sync gate measures the length of the water column so it's interesting
    to know this distance. But because the interface is saturated, only the
    flank is used here.

    The sync amplitude says something about where data is extremely attenuated
    (most likely due to non-parallel surface).

    The subsequent gates measure the material so all measurements are included
    there.

    """
    gate_0 = measurement_settings.gates[0]
    gate_a = measurement_settings.gates[1]
    sample_rate = processor_settings.sample_rate * Q_("Hz")
    desired_units = units.thickness_units
    water_factor = (
        _samp_to_thick(1, sample_rate, material_velocity[str(gate_0.id)] * Q_("m/s"))
        .to(desired_units)
        .m
    )
    material_factor = (
        _samp_to_thick(1, sample_rate, material_velocity[str(gate_a.id)] * Q_("m/s"))
        .to(desired_units)
        .m
    )

    assert gate_a.reference_id == gate_0.id

    cscans: t.List[models.CscanSettings] = []

    default_binning = {
        "bin_size_1d": 0.5 / 12,  # ft
        "bin_function": "min",
    }
    no_filter = {
        "filter_min": None,
        "filter_max": None,
    }
    amplitude_color = {
        "color_map_name": CONVENTIONAL_CMAPS["amplitude"],
        "color_min": 0,  # Same units as the measurement %FSH
        "color_max": 150,
    }
    water_color = {
        "color_map_name": CONVENTIONAL_CMAPS["delay"],
        # These numbers are estimates: ISENS sled shape and also the DAQ
        # Setting for Delay can shift these values.
        # inches converted to samples:
        "color_min": 0.12 / water_factor,  # Units of samples!
        "color_max": 0.16 / water_factor,  # Units of samples!
    }
    material_color = {
        "color_map_name": CONVENTIONAL_CMAPS["thickness"],
        # inches converted to samples
        "color_min": 0 / material_factor,  # Units of samples!
        "color_max": (1.25 * expected_nominal) / material_factor,  # Units of samples!
    }
    # Gate 0:
    cscans.append(
        models.CscanSettings(
            title="Interface Timing",
            source=(gate_0.id, FLANK),
            quantity="Depth of water column",
            **water_color,
            **no_filter,
            **default_binning,
        )
    )
    cscans.append(
        models.CscanSettings(
            title="Interface Amplitude",
            source=(gate_0.id, AMPLITUDE),
            quantity="Amplitude",
            **amplitude_color,
            **no_filter,
            **default_binning,
        )
    )
    # Gate A
    cscans.append(
        models.CscanSettings(
            title="Mode-2, flank-to-flank",
            source=(gate_a.id, FLANK),
            quantity="Thickness",
            **material_color,
            **no_filter,
            **default_binning,
        )
    )
    cscans.append(
        models.CscanSettings(
            title="Mode-2, peak-to-peak",
            source=(gate_a.id, PEAK),
            quantity="Thickness",
            **material_color,
            **no_filter,
            **default_binning,
        )
    )
    cscans.append(
        models.CscanSettings(
            title="1st Back-wall Amplitude",
            source=(gate_a.id, AMPLITUDE),
            quantity="Amplitude",
            **amplitude_color,
            **no_filter,
            **default_binning,
        )
    )
    # Gate B (optional)
    if len(measurement_settings.gates) == 3:
        gate_b = measurement_settings.gates[2]
        assert gate_b.reference_id == gate_a.id
        cscans.append(
            models.CscanSettings(
                title="Mode-3, flank-to-flank",
                source=(gate_b.id, FLANK),
                quantity="Thickness",
                **material_color,
                **no_filter,
                **default_binning,
            )
        )
        cscans.append(
            models.CscanSettings(
                title="Mode-3, peak-to-peak",
                source=(gate_b.id, PEAK),
                quantity="Thickness",
                **material_color,
                **no_filter,
                **default_binning,
            )
        )
        cscans.append(
            models.CscanSettings(
                title="1st Back-wall Amplitude",
                source=(gate_b.id, AMPLITUDE),
                quantity="Amplitude",
                **amplitude_color,
                **no_filter,
                **default_binning,
            )
        )

    cscans.append(
        models.CscanSettings(
            source=DENSITY_CSCAN_NAME,
            title="Number of A-scans per bin",
            quantity="count",
            color_map_name=CONVENTIONAL_CMAPS[DENSITY_CSCAN_NAME],
            color_min=0,
            color_max=100,
            bin_size_1d=0.5,
            bin_function="count",
        )
    )

    return cscans


def _continue_sequence(gate: models.Gate, name, threshold, start_index, end_index):
    # Create a new gate which makes reference to the given gate.
    return models.Gate(
        id=gate.id + 1,
        name=name,
        threshold=threshold,
        start_index=start_index,
        end_index=end_index,
        reference_id=gate.id,
    )


@dataclass
class GateResult:
    """A description of the result of applying a gate

    Note: The default arguments describe a gate result which missed.

    This class is a useful type intended to help with visualization of the
    reference points established by a gate, for example as would be shown on a
    plot of an A-scan.

    """

    id: int = -1
    name: str = "missed"
    threshold: t.Union[float, int] = 0
    start_index: int = 0
    end_index: int = 0
    prior_result: t.Union["GateResult", int] = 0
    flank: t.Tuple[int, float] = (0, 0.0)
    peak: t.Tuple[int, float] = (0, 0.0)

    @property
    def shape(self):
        """Returns the shape of the gate with amplitude rounded"""
        return (round(self.threshold, 2), self.start_index, self.end_index)

    @property
    def reference_point(self):
        """The prior result reference point"""
        if isinstance(self.prior_result, int):
            index = self.prior_result
        else:
            index, _ = self.prior_result.flank
        return index

    @property
    def adjusted_shape(self):
        prior_ref = self.reference_point
        threshold, start, end = self.shape
        return (
            threshold,
            start - prior_ref,
            end - prior_ref,
        )

    @property
    def missed(self):
        crossing_index, _ = self.flank
        return crossing_index == self.end_index

    @property
    def measured_points(self):
        # Returns the measured points in a format for scatter plots.
        return list(zip(self.flank, self.peak))

    @property
    def flank_measured(self):
        """The measured crossing edge distance"""
        distance, _ = self.flank
        return distance - self.reference_point

    @property
    def peak_measured(self):
        """The measured peak-to-peak distance"""
        if isinstance(self.prior_result, int):
            index = self.prior_result
        else:
            index, _ = self.prior_result.peak

        distance, amplitude = self.peak
        return distance - index, amplitude


class MeasurementSetupError(Exception):
    """Raised when a gate configuration is wrong"""


def tcg_from_template(tcg_template: models.TCGTemplate, total_length: int):
    tcg_array = np.ones(total_length, dtype=np.float32)

    if len(tcg_template) < 1:
        raise MeasurementSetupError("TCG template must have 1 or more points")

    # Note: this implementation creates a sudden jump at the first TCG template
    # point from gain factor of 1 to that first point factor. This might be a
    # good thing depending on how the TCG template points are created to begin
    # with. The alternative is smoothly changing gain from 1 at sample 0 to the
    # first point.
    point = tcg_template[0]
    previous_sample, previous_factor = point.sample, point.factor
    for point in tcg_template[1:]:
        # This segment of TCG curve will be a linear interpolation between this
        # point and the previous one.
        dx = point.sample - previous_sample
        segment = np.linspace(previous_factor, point.factor, dx, endpoint=False)
        if point.sample > total_length:
            part = total_length - previous_sample
            tcg_array[previous_sample:total_length] = segment[:part]
            # At this point we've filled up the array completely. For example
            # when the last point on the TCG curve is actually past the end of
            # the total_length.
            break
        else:
            tcg_array[previous_sample : point.sample] = segment

        previous_sample, previous_factor = point.sample, point.factor
    else:
        # At this point the TCG template was not long enough to completely fill
        # the A-scan total_length, so we'll continue the TCGCurve to the
        # total_length using the previous factor.
        tcg_array[previous_sample:] = previous_factor

    return tcg_array


def unit_conversion_map(settings: models.UTScopeConfig):
    """Compute the unit conversion factors for gate based measurements

    The Gate Framework produces time measurements in units of samples. These
    unit conversion factors allow us to convert the samples unit into distance
    unit using the appropriate material velocity and other parameters.

    Returns:
        A map of unit conversion factors for each gate id.

    """
    conversion_map: t.Dict[models.GateID, float] = {}
    thickness_units = settings.units.thickness_units
    fs = settings.processor_settings.sample_rate * Q_("Hz")

    for gate in settings.measurement_settings.gates:
        v = settings.material_velocity[str(gate.id)] * Q_("m/s")
        conversion_map[gate.id] = time_resolution(fs, v, thickness_units)

    return conversion_map


def time_resolution(
    sample_rate: pint.Quantity,
    material_velocity: pint.Quantity,
    desired_units: pint.Quantity,
):
    """Returns the thickness resolution for one sample"""
    return _samp_to_thick(1, sample_rate, material_velocity).to(desired_units).m


def tcg_curve_to_aos(
    run_settings: models.UTScopeConfig,
) -> t.List[t.Tuple[float, float]]:
    """Returns the TCG in a format compatible with AOS

    Time in microseconds and gain in db
    """
    # Convert sample time to time in microseconds
    # Convert gain factor to db
    fs = run_settings.processor_settings.sample_rate * Q_("Hz")
    time = (1 / fs).to("us").m
    template = run_settings.measurement_settings.tcg_curve.template
    aos_curve = [
        (point.sample * time, 20 * np.log10(point.factor)) for point in template
    ]
    return aos_curve


def tcg_curve_to_evident(run_settings: models.UTScopeConfig):
    """Returns the TCG in a format compatible with evident

    Time in nanoseconds and gain in db
    """
    # Convert sample time to time in nanoseconds
    # Convert gain factor to db
    fs = run_settings.processor_settings.sample_rate * Q_("Hz")
    time = (1 / fs).to("ns").m
    template = run_settings.measurement_settings.tcg_curve.template
    evident_curve = [
        (point.sample * time, 20 * np.log10(point.factor)) for point in template
    ]
    return evident_curve
