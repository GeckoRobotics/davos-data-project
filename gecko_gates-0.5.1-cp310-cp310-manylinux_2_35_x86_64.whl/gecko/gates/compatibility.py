"""A compatibility layer between the UT Gate Framework and signalprocessing

The entire gate-framework might have been implemented in the signalprocessing
project, however there are some good reason to move away from the specific
pattern used in that project of `algorithm_config.instantiate` as a factory
function for Thicknesser algorithms. As well as some of the "heavy weight"
aspects of that project.

So instead of moving the gate-framework into the signalprocessing project, and
instead of using signalprocessing as a middle-man for the gate-framework we
directly emulate the Thicknesser class here in order to provide exactly the
functionality that IDATools requires on top of the gate-framework.

"""
import typing as t

import numpy as np
from matplotlib.axes import Axes
from numpy.typing import NDArray

from gecko.gates.common import GateResult, unit_conversion_map
from gecko.gates.methods import make_pipeline, measure_display_ascan
from gecko.gates.models import GateID, GateMeasurement, GateSource, UTScopeConfig


class GateFrameworkThicknesser:
    """A stand-in for `signalprocessing.ultrasound.thicknesser.Thicknesser`

    This is intended to provide the simplest integration possible between
    IDATools and the Gate-framework by providing the same "ruler" interface
    which IDATools expects on-top of the gate-framework.

    """

    debug: bool = False
    ascan: NDArray[np.int16]
    measured_ascan: NDArray[np.float32]
    _results: t.Dict[GateID, GateResult]
    samples: t.Union[int, None]
    result: float
    score: float
    _gate_colors = {0: "b", 1: "r", 2: "g"}

    def __init__(self, source: GateSource, run_settings: UTScopeConfig):
        # The source describes the particular measurement that the user intends
        # to focus on in IDATools.
        # run_settings are the complete gate-framework configuration including
        # display settings.
        self.run_settings = run_settings
        self._pipeline = make_pipeline(
            run_settings.digitizer, run_settings.processor_settings
        )

        # Setup unit conversion so that measure() can return a float thickness.
        self._gate_id, self._measurement = source
        unit_conversion = unit_conversion_map(run_settings)
        self._conversion_factor = unit_conversion[self._gate_id]

    @property
    def gate_result(self) -> GateResult:
        return self._results[self._gate_id]

    def measure(self, ascan: NDArray[np.float32]):
        """process and apply gates, returning the correct thickness.

        Store some intermediate values for access later.

        Returns:
            A float thickness in inches.

        """
        processed_ascan = self._pipeline.process(ascan).astype(np.float32)
        measured_ascan, results = measure_display_ascan(
            processed_ascan,
            self.run_settings.processor_settings,
            self.run_settings.measurement_settings,
            0,
        )
        gate_result = results[self._gate_id]
        flank_sample = gate_result.flank_measured
        peak_sample, peak_amplitude = gate_result.peak_measured

        if gate_result.missed:
            samples = None
            thickness = np.nan
        else:
            samples = (
                flank_sample
                if self._measurement is GateMeasurement.flank
                else peak_sample
            )
            thickness = samples * self._conversion_factor

        self.ascan = ascan
        self.measured_ascan = measured_ascan
        self._results = results
        self.samples = samples
        self.result = thickness
        self.score = peak_amplitude
        return thickness

    def draw_to(self, axes: Axes):
        """Draw an explanation of how the algorithm arrived at the measurement.

        This function implements both the `draw_to` found in the Thicknesser
        base class, but also the `add_to_plot` functionality found in some
        subclasses.

        Returns:
            A list of matplotlib artists so that the owner of the given axes
            can manage the deletion of them later.

        """
        # Here we duplicate the `Thicknesser.draw_to` code:
        artists = []
        artists.extend(axes.plot(self.measured_ascan, c="black"))
        for point in self.good_peaks:
            artists.append(axes.axvline(point, c="r"))
        text = f"Amplitude: {self.score:0.3f}\nThickness: {self.result:7.5f}"
        artists.append(
            axes.annotate(
                text,
                xy=(0.999, 0.99),
                xycoords="axes fraction",
                color="k",
                ha="right",
                va="top",
            )
        )
        # And then implement the `add_to_plot` equivalents
        for gate_id, result in self._results.items():
            color = self._gate_colors[gate_id]
            threshold, start, end = result.shape
            x, y = result.measured_points
            artists.append(axes.scatter(x, y, marker="o", c=color))
            artists.extend(axes.plot([start, end], [threshold, threshold], color=color))

        return artists

    @property
    def good_peaks(self):
        good_points = []
        if self._measurement is GateMeasurement.flank:
            # Return the position of each of the non-missed gate flanks
            items = list(self._results.items())
            good_points = [
                result.flank[0]
                for gate_id, result in self._results.items()
                if not result.missed
            ]
        else:
            # Return the position of each of the gate peaks, except for cases
            # where the prior gate missed.
            items = list(self._results.items())
            sync_id, sync_result = items[0]
            previous = sync_result
            good_points.append(sync_result.peak[0])
            for gate_id, result in items[1:]:
                if previous is not None and not previous.missed:
                    good_points.append(result.peak[0])
                previous = result

        return np.array(good_points, dtype=np.int16)
