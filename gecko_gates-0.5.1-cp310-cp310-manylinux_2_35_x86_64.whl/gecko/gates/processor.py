"""Processing and filtering of ultrasound signals

Note:

Fork of `signalprocessing.ultrasound.preprocessing`

While it is undesirable to copy code like this, the dependency issues related
to including signalprocessing in this project were expected to be worse in the
short term. Future work will either solve the dependency issues with
signalprocessing or otherwise consolidate these two implementations.

"""
import typing as t

import numpy as np
import scipy.signal

from gecko.gates.models import Digitizer, ProcessorSettings, RectifierMode


def make_pipeline(digitizer: Digitizer, settings: ProcessorSettings):
    dtype_max = np.iinfo(digitizer.sample_size.dtype).max
    dtype_min = np.iinfo(digitizer.sample_size.dtype).min

    _equalizer = Equalizer(dtype_min, dtype_max)
    _scaler = Scaler(settings.saturation_percent / dtype_max)
    stages: t.List[AscanProcessor] = [
        _equalizer,
        _scaler,
    ]
    if settings.enable_filtering:
        stages.append(
            BandPassFIR(
                (settings.filter_low_cutoff, settings.filter_high_cutoff),
                digitizer.sample_rate,
                order=47,
            )
        )
    if settings.enable_rectification:
        stages.append(Rectifier(settings.rectification))
    if settings.enable_smoothing:
        # Note: This smoothing function is not intended for use on un-rectified
        # signals, although it works, it produces unhelpful results.
        stages.append(
            CompositeMaxTriangularSmoother(
                settings.smoother_max_length, settings.smoother_avg_length
            )
        )

    return ProcessorPipeline(*stages)


def db_to_mag(decibels):
    """Convert logarithmically-scaled decibel units to linearly-scaled magnitudes.

    Args:
        decibels: An array of logarithmically-scaled decibel values.

    Returns:
        magnitudes: The input decibels array converted to linearly-scaled units.

    Notes:
        decibels = 20 * log_10(magnitude)
    """
    return 10 ** (decibels / 20)


class AscanProcessor:
    """Base class for A-scan preprocessing

    This class implements the "identity" function for preprocessing. In other words, the
    value returned from its ``process()`` method is equal to its input.
    """

    def __init__(self):
        pass

    def process(self, ascan):
        """Args:
            ascan: The input A-scan to apply preprocessing to

        Returns:
            preprocessed_ascan: The preprocessed version of ``ascan`` (same as
                the input ``ascan`` in this function)

        """
        return ascan


class Equalizer(AscanProcessor):
    """Equalizes the minimum and maximum value to the lower magnitude value
    Magnitude difference must be exactly 1

    Attributes:
        min_value: The minimum value possible in the A-scan
        max_value: The maximum value possible in the A-scan
    """

    def __init__(self, min_value, max_value):
        if not isinstance(min_value, (int, float)) or not isinstance(
            max_value, (int, float)
        ):
            raise ValueError(
                f"Invalid min/max value {min_value}/{max_value}, must be a float or int"
            )
        diff = min_value + max_value
        if abs(diff) != 1:
            raise ValueError(
                f"Invalid min/max value, magnitude difference {abs(diff)}, must be one"
            )
        if diff > 0:
            self.target_value = max_value
            self.replacement = max_value - diff
        else:
            self.target_value = min_value
            self.replacement = min_value - diff

    def process(self, ascan):
        """
        Args:
            ascan: The input A-scan to apply equlization to

        Returns:
            preprocessed_ascan: The equalized version of ``ascan``

        """
        return np.where(ascan == self.target_value, self.replacement, ascan)


class Scaler(AscanProcessor):
    """Multiplies A-scan amplitude by a scalar value

    Attributes:
        factor: The value to scale input A-scans' amplitude by
    """

    def __init__(self, factor):
        if not isinstance(factor, (int, float)):
            raise ValueError(f"Invalid factor {factor}, must be a float or int")
        self.factor = factor

    def process(self, ascan):
        """
        Args:
            ascan: The input A-scan to apply scaling to

        Returns:
            preprocessed_ascan: The scaled version of ``ascan``

        """
        return ascan * self.factor


class DigitalGain(AscanProcessor):
    """Amplifies (or attenuates) A-scan amplitude by a decibel (dB) scalar value

    Attributes:
        factor_db: The value in decibels to scale input A-scans' amplitude by.

    Notes:
        See ``db_to_mag()`` for the calculation used to convert decibels to linear
        amplitude units.

    """

    def __init__(self, factor_db):
        if not isinstance(factor_db, (int, float)):
            raise ValueError(f"Invalid factor {factor_db}, must be a float or int")
        self.factor_db = factor_db

    def process(self, ascan):
        """
        Args:
            ascan: The input A-scan to apply gain to

        Returns:
            preprocessed_ascan: The amplified or attenuated version of ``ascan``

        """
        return ascan * db_to_mag(self.factor_db)


class IIRFilterProcessor(AscanProcessor):
    """Generic infinite impulse response (IIR) filter processor

    Attributes:
        cutoff_freq_hz: The cutoff frequency of the filter in hertz. Must be a
            length 2 tuple if ``mode`` is "bandpass".
        sampling_rate_hz: The digitization sampling rate of input A-scans in hertz
        mode: Controls the filter mode of this processor. May be one of
            "bandpass", "lowpass", "highpass", or "bandstop". See the argument
            ``btype`` on ``scipy.signal.iirfilter()`` for more details.
        order: Controls the order of the IIR filter, with higher orders
            resulting in stronger frequency attenuation but with higher
            computation cost and more phase shifting. See the argument ``N`` on
            ``scipy.signal.iirfilter()`` for more details.

    """

    def __init__(
        self, cutoff_freq_hz, sampling_rate_hz: float, mode: str, order: int = 4
    ):
        self._cutoff_freq_hz = cutoff_freq_hz
        self._sampling_rate_hz = sampling_rate_hz
        self._mode = mode
        self._order = order
        self._set_filter_coefs()

    @property
    def cutoff_freq_hz(self):
        return self._cutoff_freq_hz

    @cutoff_freq_hz.setter
    def cutoff_freq_hz(self, cutoff):
        self._cutoff_freq_hz = cutoff
        self._set_filter_coefs()

    @property
    def sampling_rate_hz(self):
        return self._sampling_rate_hz

    @sampling_rate_hz.setter
    def sampling_rate_hz(self, rate):
        self._sampling_rate_hz = rate
        self._set_filter_coefs()

    @property
    def mode(self):
        return self._mode

    @mode.setter
    def mode(self, mode):
        self._mode = mode
        self._set_filter_coefs()

    @property
    def order(self):
        return self._order

    @order.setter
    def order(self, order):
        self._order = order
        self._set_filter_coefs()

    def _set_filter_coefs(self):
        self._b_coef, self._a_coef = scipy.signal.iirfilter(
            self._order,
            self._cutoff_freq_hz,
            btype=self._mode,
            fs=self._sampling_rate_hz,
        )

    def process(self, ascan):
        """
        Args:
            ascan: The input A-scan to smooth

        Returns:
            The filtered version of ``ascan``

        """
        return scipy.signal.lfilter(self._b_coef, self._a_coef, ascan)


class BandPassFilter(IIRFilterProcessor):
    """Attenuates signals outside lower and upper cutoff frequencies"""

    def __init__(self, cutoff_freq_hz, sampling_rate_hz, order=4):
        super().__init__(cutoff_freq_hz, sampling_rate_hz, "bandpass", order=order)


class BandPassFiltFilt(AscanProcessor):
    """Same as `BandPassFilter` but uses forward-backwards filtering

    Cascade of second order sections results in a zero phase filter meaning a
    constant (and zero) time delay for all frequency content in the signal.

    However...This has roughly 10x the performance cost.

    Result is equivalent to 2x the given order.

    """

    def __init__(self, cutoff_freq_hz, sampling_rate_hz: float, order: int = 2):
        self._order = order
        self._sos = scipy.signal.iirfilter(
            order,
            cutoff_freq_hz,
            btype="bandpass",
            fs=sampling_rate_hz,
            output="sos",
        )

    def process(self, ascan):
        return scipy.signal.sosfiltfilt(self._sos, ascan)


class BandPassFIR(AscanProcessor):
    """Linear phase finite impulse response"""

    def __init__(self, cutoff_freq_hz, sample_rate_hz: float, order: int = 47):
        self._order = order
        self._filt = scipy.signal.firwin(
            order + 1, cutoff_freq_hz, fs=sample_rate_hz, pass_zero="bandpass"
        )

    def process(self, ascan):
        return scipy.signal.convolve(ascan, self._filt, mode="same", method="direct")


class MovingAverageSmoother(AscanProcessor):
    """Smooths rectified signals using a rectangular moving average

    Attributes:
        average_len: The width of the moving average filter in number of
            samples. Larger values will result in more smoothing, but will
            attenuate narrow peaks.

    """

    def __init__(self, average_len=15):
        self.average_len = average_len
        self.mav_filter = np.ones(average_len) / average_len

    def process(self, ascan):
        """
        Args:
            ascan: The input A-scan to smooth

        Returns:
            The smoothed version of ``ascan``
        """
        return np.convolve(ascan, self.mav_filter, "same")


class TriangularMovingAverageSmoother(MovingAverageSmoother):
    """Smooths rectified signals using a rectangular moving average

    Attributes:
        average_len: The width of the moving average filter in number of
            samples. Larger values will result in more smoothing, but will
            attenuate narrow peaks.

    """

    def __init__(self, average_len=15):
        self.average_len = average_len
        self.mav_filter = np.concatenate(
            (np.linspace(0, 1, average_len // 2), np.linspace(1, 0, average_len // 2))
        )
        self.mav_filter = self.mav_filter / np.sum(self.mav_filter)


class MovingMaxSmoother(AscanProcessor):
    """Smooths signals by finding the local maximum for each signal

    Attributes:
        average_len: The width of the moving average filter in number of
            samples. Larger values will result in more smoothing, but will
            attenuate narrow peaks.

    """

    def __init__(self, smoothing_len=5):
        self.smoothing_len = smoothing_len

    def process(self, ascan):
        """Process an A-scan

        Args:
            ascan: The input A-scan to smooth

        Returns:
            The smoothed version of ``ascan``

        """
        moving_indices = np.arange(len(ascan))[:, np.newaxis] + np.arange(
            self.smoothing_len
        )

        padded_ascan = np.pad(ascan, self.smoothing_len // 2)

        smoothed_ascan = np.max(padded_ascan[moving_indices], axis=1)
        return smoothed_ascan


class CompositeMaxTriangularSmoother(AscanProcessor):
    """Combines moving max and triangular moving average smoothing

    Attributes:
        max_smoothing_len: Controls the amount of max smoothing, see
            ``MovingMaxSmoother.smoothing_len``
        triangular_average_len: Controls the amount of triangular smoothing,
            see ``TriangularMovingAverageSmoother.average_len``

    """

    # TODO: Provide options which allow us to more reliably get an "envelope"
    # of the signal across a wide range of signal configurations. For example
    # when given 5MHz transducers, and negative half rectification, smoothing
    # does basically nothing for us.

    def __init__(self, max_smoothing_len=5, triangular_average_len=10):
        self.max_smoother = MovingMaxSmoother(smoothing_len=max_smoothing_len)
        self.tri_smoother = TriangularMovingAverageSmoother(
            average_len=triangular_average_len
        )

    def process(self, ascan):
        """Process an A-scan

        Args:
            ascan: The input A-scan to smooth

        Returns:
            The smoothed version of ``ascan``
        """
        return self.tri_smoother.process(self.max_smoother.process(ascan))


class Rectifier(AscanProcessor):
    """Applies one of several rectification modes to input A-scans

    Attributes:
        mode: The type of rectification to apply with this processor

    """

    def __init__(self, mode):
        if not isinstance(mode, RectifierMode):
            raise ValueError(f"Invalid mode {mode}, must be a {RectifierMode}")
        self.mode = mode

    def process(self, ascan):
        """Process an A-scan

        Args:
            ascan: The input A-scan to rectify

        Returns:
            preprocessed_ascan: The rectified version of ``ascan``, with the
                type of rectification depending on the mode set in this object

        """
        if self.mode is RectifierMode.half_wave_positive:
            preprocessed_ascan = np.fmax(ascan, 0)

        elif self.mode is RectifierMode.half_wave_negative:
            preprocessed_ascan = -1 * np.fmin(ascan, 0)

        elif self.mode is RectifierMode.full_wave:
            preprocessed_ascan = np.abs(ascan)

        return preprocessed_ascan


class ProcessorPipeline(list):
    """Allows chaining of several ``AscanProcessor``s into one composite processor

    Note that this class inherits from ``list``, so typical list operations like
    ``append()`` or ``insert()`` may be used to modify the order of processors.
    """

    def __init__(self, *processors):
        super().__init__(processors)
        for processor in processors:
            if not isinstance(processor, AscanProcessor):
                raise ValueError(
                    f"Invalid processor {processor}, "
                    f"must be a subclass of {AscanProcessor}"
                )

    def process(self, ascan):
        """Process an A-scan

        Args:
            ascan: The input A-scan to apply processing to

        Returns:
            preprocessed_ascan: The preprocessed version of ``ascan`` with all
                processors applied in sequential order

        """
        for processor in self:
            ascan = processor.process(ascan)
        return ascan
