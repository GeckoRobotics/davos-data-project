"""Methods used to apply gates to A-scans

In the gate framework we think of a process with 3 steps:

    Process -> Measure -> Align -> Display

Process consists of all the things that must be done to transform the A-scans
according to the inspection technique and which must be done prior to applying
any gates.

Measurement consists of applying the gates to establish meaningful reference
points within the A-scan. Useful NDE measurements such as material thickness
come out of this.

Alignment is how we format the A-scans for display. Using one or more of the
reference points established by measurement.

This module implements useful methods for doing each of these things.

"""
import logging
import typing as t

import numpy as np
from numpy.typing import NDArray

from gecko.gates import _gate_impl
from gecko.gates.common import (
    CSCAN_DTYPE,
    FLANK,
    PEAK,
    GateResult,
    Measurements,
    tcg_from_template,
)
from gecko.gates.models import (
    Digitizer,
    Gate,
    GateID,
    MeasurementSettings,
    ProcessorSettings,
)
from gecko.gates.processor import make_pipeline

LOGGER = logging.getLogger(__name__)


class MeasurementError(Exception):
    """Raised when an error occurs during measurement"""


class PipelineProcessor:
    """Class to wrap processing and measuring functionality into an API
    that is more friendly to processing live data
    """

    def __init__(self, digitizer, processor_settings, measure_settings):
        """
        digitizer: A digitizer for describing the format of the raw A-scan

        processor_settings, measurement_settings:
            Complete set of configuration which describes how gates should be
            applied.
        """
        self.pipeline = make_pipeline(digitizer, processor_settings)
        self.processor_settings = processor_settings
        self.measure_settings = measure_settings

    def process_ascan(self, raw_ascan):
        """Apply the processor settings to the given raw A-scans

        `raw_ascan` should be a numpy array A-scan

        Returns the A-scan transformed according to the given settings.

        Note alignment is not done here.

        """
        return self.pipeline.process(raw_ascan).astype(np.float32)

    def measure_ascan(self, processed_ascan):
        """See measure_display_scan"""
        return measure_display_ascan(
            processed_ascan, self.processor_settings, self.measure_settings, 0
        )

    def process_and_measure(self, raw_ascan):
        """Processes raw A-scans, then applies measurement to them"""
        return self.measure_ascan(self.process_ascan(raw_ascan))


def process_ascans_1D(
    raw_ascans: NDArray[t.Any],
    digitizer: Digitizer,
    processor: ProcessorSettings,
):
    """Apply the processor settings to the given collection of raw ascans

    These are a specific subset of the signal processing steps which must be
    done before any gates are applied.

    Other "processing" steps like alignment or applying TCG curves are not done
    here, but must be done as part of the "measurement" step.

    Args:
        raw_ascans: 1-D array of A-scans such as a B-scan
        digitizer: a description of the type of A-scans being processed
        processor: Processor settings describing how processing should be done

    Returns:
        An array of A-scans of the same shape as the raw_ascans

    """
    pipeline = make_pipeline(digitizer, processor)
    processed = np.zeros(raw_ascans.shape, dtype=np.float32)
    for i, ascan in enumerate(raw_ascans):
        processed[i, :] = pipeline.process(ascan)
    return processed


def process_ascans_2D(
    raw_ascans: NDArray[t.Any], digitizer: Digitizer, processor: ProcessorSettings
) -> NDArray[np.float32]:
    """Same as `process_ascans_1D` but for a 2d array of A-scans

    While not used by UT-scope through any user interface, it can be a useful
    feature when the complete set of raw A-scans is already loaded into memory.

    """
    pipeline = make_pipeline(digitizer, processor)
    processed = np.zeros(raw_ascans.shape, dtype=np.float32)
    for i, bscan in enumerate(raw_ascans):
        for j, ascan in enumerate(bscan):
            processed[i, j, :] = pipeline.process(ascan)
    return processed


def measure_and_align(
    ascans: NDArray[t.Any],
    processor_settings: ProcessorSettings,
    measurement_settings: MeasurementSettings,
):
    """Measure the given processed A-scans and apply alignment

    See also `process_ascans_1d`

    """
    gate_sequence = measurement_settings.gate_sequence

    measures = measure_ascans(ascans, measurement_settings)
    reference_sum = cumulative_sum(measurement_settings, measures)

    _gate_ids = [gate.id for gate in gate_sequence]
    alignment_index = _gate_ids.index(measurement_settings.alignment_gate)
    _alignment_points, alignment_miss = reference_sum[
        measurement_settings.alignment_gate
    ]
    alignment_points = np.array(_alignment_points, copy=True)
    alignment_subset = alignment_points != alignment_miss

    first_points, _ = reference_sum[_gate_ids[0]]

    front_padding = normalize_padding(
        first_points, alignment_points, alignment_miss, processor_settings.front_padding
    )
    alignment_points[alignment_subset] -= front_padding

    aligned_bscan = align_ascans(
        ascans,
        alignment_points,
        alignment_miss,
        processor_settings.ascan_length,
    )
    aligned_scatter = align_raw_scatter_plots(
        reference_sum,
        alignment_points,
        alignment_miss,
        alignment_index,
    )
    return aligned_bscan, aligned_scatter, alignment_points, alignment_miss


def measure_and_truncate(
    ascans: NDArray[t.Any],
    processor_settings: ProcessorSettings,
    measurement_settings: MeasurementSettings,
):
    """Measure the given processed A-scans and truncate the result

    Similar to measure and align except for the case where no alignment at all
    is applied.

    """
    gate_sequence = measurement_settings.gate_sequence

    measures = measure_ascans(ascans, measurement_settings)
    reference_sum = cumulative_sum(measurement_settings, measures)

    _gate_ids = [gate.id for gate in gate_sequence]
    first_points, first_points_miss = reference_sum[_gate_ids[0]]

    # TODO: The display_0 in the unaligned case should actually be a constant
    # value. It really needs to be tied to the theoretical position which
    # represents the face of the sleds, the expected minimum position of the
    # interface.
    display_0 = normalize_truncation(
        first_points, first_points_miss, processor_settings.front_padding
    )

    constant_ref = np.full(ascans.shape[0], fill_value=display_0, dtype=np.int16)
    ref_sentinel = -1
    shifted_bscan = align_ascans(
        ascans,
        constant_ref,
        ref_sentinel,
        processor_settings.ascan_length,
    )
    shifted_scatter = align_raw_scatter_plots(
        reference_sum,
        constant_ref,
        ref_sentinel,
        -1,
    )
    return shifted_bscan, shifted_scatter, constant_ref, ref_sentinel


def measure_ascans(
    ascans: NDArray[np.float32], setup: MeasurementSettings
) -> Measurements:
    """Apply the sequence of gates to an array of processed A-scans

    Args:
        ascans:
            1D Array of unaligned processed A-scans. See `process_ascans_1D`

        setup:
            The complete set of measurement configurations which describe how
            the A-scans should be measured.

    In this case the first gate is always given relative to sample 0 of the
    A-scan, while all subsequent gates are given relative to the prior gates
    flank detection point.

    """
    measurements: Measurements = {}
    gate_sequence = setup.gate_sequence

    ################################################################################
    # Here we apply the first gate (sync gate) which establishes the zero
    # reference for the next gate (gates?)
    sync_gate = gate_sequence[0]
    end_index_sum = int(sync_gate.end_index)
    # No prior gate and no prior gate misses. Indicate that with an all_zero
    # reference, and a non_zero gate_miss_value.
    all_zeros = np.zeros(len(ascans), dtype=np.int16)
    non_zero = 1

    c_time, a_time, ampl = _gate_impl.measure_bscan_sync(
        ascans, all_zeros, *sync_gate.shape, non_zero
    )
    measurements[sync_gate.id] = np.array(
        list(zip(c_time, a_time, ampl)), dtype=CSCAN_DTYPE
    )

    # the next gate is always applied relative to the flank by
    # convention.
    zero_reference = c_time
    flank_to_peak_diff = a_time - c_time
    flank_to_peak_diff[c_time == sync_gate.end_index] = 0

    if setup.tcg_enabled and setup.tcg_curve.gate_id == sync_gate.id:
        name, id = sync_gate.name, sync_gate.id
        LOGGER.debug("Applying TCG with respect to %s (id: %d)", name, id)
        tcg_array = tcg_from_template(setup.tcg_curve.template, 2000)
        ascans = _apply_tcg_1D(ascans, zero_reference, tcg_array, end_index_sum)

    for gate in gate_sequence[1:]:
        c_time, a_time, ampl = _gate_impl.measure_bscan_sync(
            ascans, zero_reference, *gate.shape, end_index_sum
        )
        # here, a_time is a flank to peak distance which is not a
        # useful NDE measurement, convert that into peak to peak measurement
        # using the prior gates difference.
        measurements[gate.id] = np.array(
            list(zip(c_time, a_time - flank_to_peak_diff, ampl)),
            dtype=CSCAN_DTYPE,
        )
        end_index_sum += gate.end_index
        zero_reference += c_time
        # `zero_reference` is a cumulative sum of c_time values for each gate
        # (some hit, some missed) which means that at each stage we have to
        # "upgrade" each new miss to a consistent sentinel value for this sum.
        missed = c_time == gate.end_index
        zero_reference[missed] = end_index_sum
        flank_to_peak_diff = a_time - c_time
        flank_to_peak_diff[c_time == gate.end_index] = 0

        if setup.tcg_enabled and setup.tcg_curve.gate_id == gate.id:
            name, id = gate.name, gate.id
            LOGGER.debug("Applying TCG with respect to %s (id: %d)", name, id)
            tcg_array = tcg_from_template(setup.tcg_curve.template, 2000)
            ascans = _apply_tcg_1D(ascans, zero_reference, tcg_array, end_index_sum)

    return measurements


def measure_ascans_2D(ascans, setup: MeasurementSettings):
    """Convenience function to apply the given Setup to a 2D array of A-scans

    The A-scans here are assumed to be "raw" A-scans without alignment applied.
    For a version of this function intended to operate on a 2D array of aligned
    A-scans see

    This method is expected to be useful when the 2D array of A-scans is
    already loaded into memory.

    """
    # TODO: do we get this for free through one of Numpy's mechanism?
    cscan_shape = sensor_count, bscan_length = ascans.shape[0:2]
    gate_sequence = setup.gate_sequence

    # Initialize the measurements results to zero:
    measurements: Measurements = {}
    for gate in gate_sequence:
        measurements[gate.id] = np.zeros(cscan_shape, dtype=CSCAN_DTYPE)

    # Iterate over B-scans and apply gates:
    for sensor_index in range(sensor_count):
        bscan_measures = measure_ascans(ascans[sensor_index], setup)
        # Copy the B-scan measures into the C-scan:
        for gate in gate_sequence:
            measurements[gate.id][sensor_index] = bscan_measures[gate.id]

    # Returns the dictionary of C-scans
    return measurements


def _apply_tcg(ascan: NDArray[t.Any], start: int, tcg: NDArray[t.Any]):
    """Apply time varied gain (TCG) to a single ascan"""
    tcg_ascan = np.array(ascan, copy=True)
    _gate_impl.apply_tcg(ascan, start, tcg, tcg_ascan)
    return tcg_ascan


def _apply_tcg_1D(
    ascans: NDArray[np.float32],
    starts: NDArray[t.Any],
    tcg_array: NDArray[t.Any],
    invalid_start: int,
):
    """Apply time varied gain (TCG) to an array of A-scans"""
    tcg_ascans = np.zeros(ascans.shape, dtype=np.float32)
    _gate_impl.apply_tcg_1D(ascans, starts, tcg_array, tcg_ascans, invalid_start)
    return tcg_ascans


def measure_aligned_ascans(
    ascans: NDArray[np.float32],
    processor_settings: ProcessorSettings,
    measurement_settings: MeasurementSettings,
    sync_measures: NDArray[t.Any],
) -> Measurements:
    """Like `measure_ascans`, for A-scans which have already been aligned

    The alignment which was done to the given A-scans is assumed to be the
    standard synchronization gate alignment. So `sync_measures` and
    `front_padding` describe that alignment.

    This is how A-scans stored in the Analysis files are expected to be
    re-measured during analysis.

    """
    measurements: Measurements = {}

    # Effective arguments:
    gate_sequence = measurement_settings.gate_sequence
    front_padding = processor_settings.front_padding
    tcg_enabled = measurement_settings.tcg_enabled
    tcg_reference = measurement_settings.tcg_curve.gate_id
    if tcg_enabled:
        tcg_array = tcg_from_template(
            measurement_settings.tcg_curve.template,
            processor_settings.ascan_length,
        )

    sync_gate = gate_sequence[0]
    end_index_sum = int(sync_gate.end_index)

    c_time = sync_measures[FLANK]
    a_time = sync_measures[PEAK]

    # In the aligned A-scans the 0 reference is found front_padding samples
    # into the A-scan.
    zero_reference = np.full(ascans.shape[0], fill_value=front_padding, dtype=np.int16)
    # However we must preserve where misses occurred
    zero_reference[c_time == end_index_sum] = end_index_sum

    flank_to_peak_diff = a_time - c_time
    flank_to_peak_diff[c_time == end_index_sum] = 0

    if tcg_enabled and tcg_reference == sync_gate.id:
        name, id = sync_gate.name, sync_gate.id
        LOGGER.debug("Applying TCG with respect to %s (id: %d)", name, id)
        ascans = _apply_tcg_1D(ascans, zero_reference, tcg_array, end_index_sum)

    for gate in gate_sequence[1:]:
        c_time, a_time, ampl = _gate_impl.measure_bscan_sync(
            ascans, zero_reference, *gate.shape, end_index_sum
        )
        # here, a_time is a flank to peak distance which is not a useful NDE
        # measurement, convert that into peak to peak measurement using the
        # prior gates flank-to-peak difference.
        measurements[gate.id] = np.array(
            list(zip(c_time, a_time - flank_to_peak_diff, ampl)),
            dtype=CSCAN_DTYPE,
        )
        end_index_sum += gate.end_index
        zero_reference += c_time
        # `zero_reference` is a cumulative sum of c_time values for each gate
        # (some hit, some missed) which means that at each stage we have to
        # "upgrade" each new miss to a consistent sentinel value for this sum.
        zero_reference[c_time == gate.end_index] = end_index_sum
        flank_to_peak_diff = a_time - c_time
        flank_to_peak_diff[c_time == gate.end_index] = 0

        if tcg_enabled and tcg_reference == gate.id:
            name, id = gate.name, gate.id
            LOGGER.debug("Applying TCG with respect to %s (id: %d)", name, id)
            ascans = _apply_tcg_1D(ascans, zero_reference, tcg_array, end_index_sum)

    return measurements


def measure_aligned_ascans_2D(
    ascans: NDArray[np.float32],
    processor_settings: ProcessorSettings,
    measurement_settings: MeasurementSettings,
    sync_measures: NDArray[t.Any],
):
    """Convenience function to call `measure_aligned_ascans` on a 2D array of A-scans

    Note:

    The sync gate seen in the setup is ignored as there are no protections
    against that value being modified inadvertently. So the sync_gate argument
    should be provided explicitly as a record of what *was* used to perform
    synchronization of the given A-scans.

    """
    cscan_shape = sensor_count, bscan_length = ascans.shape[0:2]

    # Initialize the measurements results to zero:
    measurements: Measurements = {}
    for gate in measurement_settings.gates[1:]:
        measurements[gate.id] = np.zeros(cscan_shape, dtype=CSCAN_DTYPE)

    # Iterate over B-scans and re-apply gates:
    for sensor_index in range(sensor_count):
        bscan_sync_measures = sync_measures[sensor_index]
        bscan_measures = measure_aligned_ascans(
            ascans[sensor_index],
            processor_settings,
            measurement_settings,
            bscan_sync_measures,
        )
        # Copy the B-scan measures into the C-scan:
        for gate in measurement_settings.gates[1:]:
            measurements[gate.id][sensor_index] = bscan_measures[gate.id]

    return measurements


def align_ascans(
    ascans: NDArray[t.Any],
    reference_points: NDArray[np.int16],
    reference_sentinel: int,
    ascan_length: int,
):
    """Return a copy of the array of A-scans aligned and truncated

    The alignment process will cause the given `reference_point` for each
    A-scan to become sample 0 of the aligned A-scans.

    """
    return _gate_impl.align_bscan(
        ascans,
        reference_points,
        0,  # front padding is already taken into account in the reference points
        ascan_length,
        reference_sentinel,
    )


def measure_display_ascan(
    ascan: NDArray[np.float32],
    processor_settings: ProcessorSettings,
    measurement_settings: MeasurementSettings,
    initial_reference_point: int,
):
    """Applies a sequence of gates to a single A-scan

    The results of this method are not the NDE measurements but are values in
    the reference frame of the A-scan given.

    This method is particularly useful when illustrating the gates results on
    an A-scan plot because the returned values are already in the same
    coordinate space as the given A-scan.

    Args:
        ascan:
            The A-scan to be measured. Could be either aligned, unaligned. See
            `intial_reference_point` below.
        processor_settings, measurement_settings:
            Complete set of configuration which describes how gates should be
            applied.
        initial_reference_point:
            Specifies the sample value in the current A-scan which represents
            the "True" sample 0. The first gate in the sequence (sync gate) is
            always applied with respect to sample 0 of the unaligned A-scan. If
            the given A-scan is unaligned then this should be set to 0. If the
            given A-scan is already aligned, then the initial reference will be
            set to the alignment sample.

    Returns:
        ascan:
            The A-scan which was measured. This A-scan might have TCG applied
            based on the configuration used in the measurement.
        measures:
            Dictionary mapping gate name to `GateResult` instances. See
            GateResult for details.

    """
    results: t.Dict[GateID, GateResult] = {}
    reference_point = int(-initial_reference_point)
    prior_result = int(-initial_reference_point)
    tcg_enabled = measurement_settings.tcg_enabled
    tcg_reference = measurement_settings.tcg_curve.gate_id

    for gate in measurement_settings.gate_sequence:
        # Initialize the result:
        gate_result = GateResult(
            id=gate.id,
            name=gate.name,
            threshold=gate.threshold,
            start_index=gate.start_index + reference_point,
            end_index=gate.end_index + reference_point,
            prior_result=prior_result,
        )
        # Make the measurement:
        flank, peak, amplitude = _gate_impl.measure_ascan(ascan, *gate_result.shape)
        # Populate the result:
        gate_result.flank = (flank, gate.threshold)
        gate_result.peak = (peak, amplitude)
        results[gate.id] = gate_result

        # Next gate is always in reference to the flank by convention
        reference_point = int(flank)

        if tcg_enabled and tcg_reference == gate.id:
            LOGGER.debug("Applying tcg with respect to %s (id: %d)", gate.name, gate.id)
            tcg_array = tcg_from_template(
                measurement_settings.tcg_curve.template, processor_settings.ascan_length
            )
            ascan = _apply_tcg(ascan, reference_point, tcg_array)

        prior_result = gate_result

    return ascan, results


CumulativeSum = t.Dict[GateID, t.Tuple[NDArray[t.Any], int]]


def cumulative_sum(
    setup: MeasurementSettings,
    measurements: Measurements,
) -> CumulativeSum:
    """Do the cumulative sum across the gate sequence for a particular mode.

    For a given detection_mode, return the reference points with respect
    to the start of the A-scans for each gate.

    This value is useful for example when doing alignment, or to describe the
    set of scatter plot points across a B-scan.

    Returns:
        Dictionary of gate id to tuples. The tuple contains the array of summed
        indexes and the sentinel value for a "miss" in the position of the
        sequence

    """
    points = {}
    value_sum = 0
    end_index_sum = 0
    for gate in setup.gate_sequence:
        values = measurements[gate.id][setup.detection_mode.name]

        end_index_sum += gate.end_index
        value_sum += values

        value_sum[values == gate.end_index] = end_index_sum
        points[gate.id] = (np.array(value_sum, copy=True), end_index_sum)

    return points


def normalize_padding(first_points, alignment_points, alignment_miss, front_padding):
    """Returns a "smart" padding value

    For the common case of aligning to the first gate in a sequence
    (interface), we want the result to be exactly front_padding samples will be
    seen prior to the interface.

    However for other alignment options (unaligned, or some gate after the
    first gate), it's not possible to have exactly front_padding samples prior
    to the interface because the interface is in different places for every
    A-scan.

    If we made sure that front_padding samples were found in front of the
    "earliest" interface it would result in "over-padding". In other words, the
    earliest signals tends to be outliers.

    If we made sure that front_padding samples were found in front of the
    "latest" interface it would result in "under-padding". In other words, the
    latest signals tend to be outliers too.

    Using the 75th percentile ends up working as a reasonable compromise to get
    the various cases to be close to each other visually. For example when
    flipping between unaligned -> first gate we will see 25% of the unaligned
    A-scans shift downwards, and 75% of the A-scans shift upwards.

    """
    # TODO: This front_padding value should be constant across the entire run,
    # not based on the current B-scan. Consider analyzing each run during
    # processing in order to determine and persist this value.
    non_misses = alignment_points != alignment_miss
    subset = (alignment_points - first_points)[non_misses]
    if subset.size == 0:
        return 0

    return int(np.percentile(subset, 75) + front_padding)


def normalize_truncation(first_points, first_points_missed, front_padding):
    """Equivalent to `normalize_padding` but for the unaligned case.

    A theoretical point to consider for the unaligned case would be the value
    determined in calibration which is actually a measurement of the true
    water-column length for the given sled/transducer setup. This would help
    normalize the behavior across sensors.

    """
    # TODO: This front_padding value should be constant across the entire run,
    # not based on the current B-scan. Consider analyzing each run during
    # processing in order to determine and persist this value.
    non_misses = first_points != first_points_missed
    subset = first_points[non_misses]
    if subset.size == 0:
        return 0

    return int(np.percentile(subset, 25) - front_padding)


def align_raw_scatter_plots(
    cumulative_sum: CumulativeSum,
    reference_points: NDArray[np.int16],
    reference_sentinel: int,
    alignment_index: int,
) -> t.List[t.Tuple[t.Any, t.Any]]:
    """Align the cumulative sum to the given reference as if for a scatter plot

    This is a simple shift of all the values in cumulative sum, except that the
    Gate miss sentinel values have to be preserved.

    Also, since this function is specifically written for the scatter plots, we
    make the choice to exclude the alignment index from the list as this would
    be a constant value after alignment and is not helpful to show on the
    scatter plots.

    Returns a pair of X, Y values for each of the measures in cumulative sum
    except for the alignment_index.

    """
    alignment_subset = reference_points != reference_sentinel
    scatter_plots = []
    total_count = len(reference_points)
    x = np.arange(total_count, dtype=float) + 0.5
    for i, (y, miss_val) in enumerate(cumulative_sum.values()):
        if i < alignment_index:
            # Stricter masking is necessary on all points prior to the
            # alignment index in the sequence so that "blank" A-scans don't get
            # scatter plot points at all.
            scatter_plots.append(
                (x[alignment_subset], (y - reference_points)[alignment_subset])
            )
        elif i == alignment_index:
            # This would be handled in exactly the same way as i >
            # alignment_index however we prefer to exclude the scatter
            # plots for the alignment index.
            continue
        elif i > alignment_index:
            non_misses = y != miss_val
            scatter_plots.append((x[non_misses], (y - reference_points)[non_misses]))

    return scatter_plots


def filter_measurements(
    measurements: NDArray[t.Any],
    gate: t.Union[None, Gate] = None,
    range_of_interest=None,
):
    """Typical filters applied to UT-scope measurements

    Returns a boolean array describing the data which is valid.

    """
    # Two types of filters are common:
    # * In the case of Gate based C-scans, filter out the sentinel values
    #   indicating "gate missed"
    # * exclude all values which fall outside of some range of interest
    valid = np.ones(measurements.shape, dtype=np.bool_)

    if range_of_interest is not None:
        mn, mx = range_of_interest
        include = (mn <= measurements) & (measurements <= mx)
        valid[:] = valid & include

    if gate is not None:
        valid[:] = valid & (measurements != gate.end_index)

    return valid
